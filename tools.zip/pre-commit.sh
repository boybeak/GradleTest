#!/bin/sh

# 定义颜色代码
COLOR_RED='\033[0;31m'
COLOR_GREEN='\033[0;32m'
COLOR_YELLOW='\033[0;33m'
COLOR_BLUE='\033[0;34m'
COLOR_RESET='\033[0m'  # 重置颜色

# 使用 printf 的日志函数
error() { printf "${COLOR_RED}[ERROR] %s${COLOR_RESET}\n" "$1"; }
warn() { printf "${COLOR_YELLOW}[WARN] %s${COLOR_RESET}\n" "$1"; }
info() { printf "${COLOR_BLUE}[INFO] %s${COLOR_RESET}\n" "$1"; }
success() { printf "${COLOR_GREEN}[SUCCESS] %s${COLOR_RESET}\n" "$1"; }

info "-------------------- PRE-COMMIT ---------------------"

PROJECT_NAME=$1
JAVA_HOME=$2

info "JAVA_HOME=$JAVA_HOME"

# 获取暂存区中的图片文件
image_files=$(git diff --cached --name-only --diff-filter=d | grep -iE '\.(png|jpe?g|webp|gif)$')
num_total_images=$(echo "$image_files" | grep -c '[^[:space:]]')  # 统计非空行的数量

info "检测到 $num_total_images 个图片文件"

info "检查可优化项..."
JAVA_CMD="$JAVA_HOME/bin/java"
"$JAVA_CMD" -Dfile.encoding=UTF-8 -jar ./.git/tools/res-checker.jar -i "$image_files" -w 48 1080 -h 48 1920 -fs 2048 204800 -dialog true -title "$PROJECT_NAME"
java_exit_code=$?

if [ $java_exit_code -gt 0 ]; then
    error "提交被优化项中断，点击忽略，则不会中断提交"
    exit 1
fi
info "可优化项检查完成"

info "-----------------------------------------------------"

exit 0